package com.wipro.CustomerAccountTracker.Exception;

public class RecordNotFoundException extends Exception {

	public RecordNotFoundException(String string) {
		// TODO Auto-generated constructor stub
		
		super(string);
	}

}
