package com.wipro.CustomerAccountTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerAccountTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
